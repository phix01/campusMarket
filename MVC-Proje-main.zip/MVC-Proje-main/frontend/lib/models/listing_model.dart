class Listing {
  final int id;
  final String title;
  final double price;
  final String description;
  final String? category;
  final String? location;
  final String? imageUrl;
  final int? sellerId;

  // ⭐ Berat'tan gelen yeni alanlar
  final String? sellerName;
  final String? sellerEmail;
  final String? sellerAvatarUrl;

  final DateTime? createdAt;

  // Android emülatör için URL normalize etme
  static String? _normalizeImageUrl(String? url) {
    if (url == null || url.isEmpty) return url;
    
    // API_BASE_URL'den host'u al (Android emülatör için 10.0.2.2)
    const apiBaseUrl = String.fromEnvironment(
      'API_BASE_URL',
      defaultValue: 'http://127.0.0.1:5000/api',
    );
    
    // Eğer URL 127.0.0.1 veya localhost içeriyorsa, API_BASE_URL'deki host ile değiştir
    if (url.contains('127.0.0.1') || url.contains('localhost')) {
      try {
        final uri = Uri.parse(apiBaseUrl);
        final imageUri = Uri.parse(url);
        
        // Port'u belirle
        final port = imageUri.hasPort ? imageUri.port : (uri.hasPort ? uri.port : null);
        
        // Yeni URL oluştur
        final normalizedUrl = Uri(
          scheme: imageUri.scheme,
          host: uri.host,
          port: port,
          path: imageUri.path,
          query: imageUri.query,
        ).toString();
        
        return normalizedUrl;
      } catch (e) {
        return url;
      }
    }
    
    return url;
  }

  const Listing({
    required this.id,
    required this.title,
    required this.price,
    required this.description,
    this.category,
    this.location,
    this.imageUrl,
    this.sellerId,
    this.sellerName,
    this.sellerEmail,
    this.sellerAvatarUrl,
    this.createdAt,
  });

  factory Listing.fromJson(Map<String, dynamic> json) {
    // Image URL'leri normalize et (Android emülatör için)
    final rawImageUrl = json['image_url'] as String?;
    final rawSellerAvatarUrl = json['seller_avatar_url'] as String?;
    
    return Listing(
      id: json['id'] as int,
      title: (json['title'] ?? '') as String,
      price: (json['price'] as num).toDouble(),
      description: (json['description'] as String?) ?? '',
      category: json['category'] as String?,
      location: json['location'] as String?,
      imageUrl: _normalizeImageUrl(rawImageUrl),
      sellerId: json['seller_id'] as int?,

      // ⭐ Güvenli şekilde ekledim
      sellerName: json['seller_name'] as String?,
      sellerEmail: json['seller_email'] as String?,
      sellerAvatarUrl: _normalizeImageUrl(rawSellerAvatarUrl),

      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'price': price,
      'description': description,
      'category': category,
      'location': location,
      'image_url': imageUrl,
      'seller_id': sellerId,

      // ⭐ Yeni alanlar JSON formatında
      'seller_name': sellerName,
      'seller_email': sellerEmail,
      'seller_avatar_url': sellerAvatarUrl,

      'created_at': createdAt?.toIso8601String(),
    };
  }
}
